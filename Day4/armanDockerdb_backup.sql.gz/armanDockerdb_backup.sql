--
-- PostgreSQL database dump
--

\restrict kXjTgFYhLSy16aa1QpVgoTjI1hMqRYxgFSOUR4p8oNLElgjrb3nQsH6cZ7GWdQW

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: visits; Type: TABLE; Schema: public; Owner: armanDev
--

CREATE TABLE public.visits (
    id integer NOT NULL,
    visited_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.visits OWNER TO "armanDev";

--
-- Name: visits_id_seq; Type: SEQUENCE; Schema: public; Owner: armanDev
--

CREATE SEQUENCE public.visits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.visits_id_seq OWNER TO "armanDev";

--
-- Name: visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: armanDev
--

ALTER SEQUENCE public.visits_id_seq OWNED BY public.visits.id;


--
-- Name: visits id; Type: DEFAULT; Schema: public; Owner: armanDev
--

ALTER TABLE ONLY public.visits ALTER COLUMN id SET DEFAULT nextval('public.visits_id_seq'::regclass);


--
-- Data for Name: visits; Type: TABLE DATA; Schema: public; Owner: armanDev
--

COPY public.visits (id, visited_at) FROM stdin;
1	2026-08-11 10:58:48.754293+00
2	2026-08-11 10:58:52.234198+00
3	2026-08-11 10:58:52.601895+00
4	2026-08-11 10:58:52.781272+00
5	2026-08-11 10:58:52.955618+00
6	2026-08-11 10:58:53.131682+00
7	2026-08-11 10:58:53.316978+00
8	2026-08-11 10:58:53.477896+00
9	2026-08-11 10:58:53.665873+00
10	2026-08-11 10:58:53.805145+00
11	2026-08-11 10:59:11.285906+00
12	2026-08-11 11:09:29.662866+00
13	2026-08-11 11:09:30.924648+00
14	2026-08-11 11:09:31.098017+00
15	2026-08-11 11:09:31.253992+00
16	2026-08-11 11:09:31.390408+00
17	2026-08-11 11:13:39.916713+00
18	2026-08-11 11:13:40.097103+00
19	2026-08-11 11:13:40.270859+00
20	2026-08-11 11:13:40.433341+00
21	2026-08-11 11:13:40.598663+00
22	2026-08-11 11:13:40.78359+00
23	2026-08-11 11:13:40.953227+00
24	2026-08-11 11:13:41.120872+00
25	2026-08-11 11:13:41.29905+00
26	2026-08-11 11:13:41.457218+00
27	2026-08-11 11:25:48.865383+00
28	2026-08-11 11:25:49.622584+00
29	2026-08-11 11:25:49.818872+00
30	2026-08-11 11:25:49.997269+00
31	2026-08-11 11:30:05.672118+00
32	2026-08-11 11:30:05.836882+00
33	2026-08-11 11:30:06.257312+00
34	2026-08-11 11:30:06.437455+00
35	2026-08-11 11:30:06.605426+00
36	2026-08-11 11:30:06.742121+00
37	2026-08-11 11:30:06.922875+00
38	2026-08-11 11:30:07.124171+00
39	2026-08-11 11:30:07.587465+00
40	2026-08-11 11:30:08.058205+00
\.


--
-- Name: visits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: armanDev
--

SELECT pg_catalog.setval('public.visits_id_seq', 40, true);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: armanDev
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict kXjTgFYhLSy16aa1QpVgoTjI1hMqRYxgFSOUR4p8oNLElgjrb3nQsH6cZ7GWdQW

